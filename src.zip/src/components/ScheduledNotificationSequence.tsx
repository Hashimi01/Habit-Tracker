import React, { useState, useEffect, useRef } from 'react';
import { Text, View, Button, Platform, StyleSheet, ScrollView, Alert } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

// --- إعداد معالج الإشعارات ---
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
    priority: Notifications.AndroidNotificationPriority.HIGH,
  }),
});

// --- المكون الرئيسي للمثال ---
export default function ScheduledNotificationSequence() {
  const [notification, setNotification] = useState<Notifications.Notification | null>(null);
  const notificationListener = useRef<Notifications.Subscription | null>(null);
  const responseListener = useRef<Notifications.Subscription | null>(null);
  const [scheduledNotificationIds, setScheduledNotificationIds] = useState<string[]>([]);

  useEffect(() => {
    registerForPushNotificationsAsync();

    const subscription1 = Notifications.addNotificationReceivedListener(function(notification: Notifications.Notification) {
      setNotification(notification);
      console.log('Notification received while app is foregrounded:', notification);
    });

    const subscription2 = Notifications.addNotificationResponseReceivedListener(function(response: Notifications.NotificationResponse) {
      console.log('Notification response received:', response);
      cancelAllScheduledNotifications();
    });

    notificationListener.current = subscription1;
    responseListener.current = subscription2;

    return () => {
      subscription1.remove();
      subscription2.remove();
    };
  }, []);

  // --- وظيفة جدولة سلسلة من التنبيهات لتبدأ في وقت محدد وبفاصل 3 ثوانٍ ---
  async function scheduleSequenceAtSpecificTime() {
    await cancelAllScheduledNotifications();

    console.log('Scheduling notification sequence with 3s interval...');
    const notificationIdentifiers: string[] = [];
    const numberOfNotifications = 10;
    const intervalSeconds = 3;

    try {
      // حساب وقت البدء (بعد دقيقة من الآن)
      const startTime = new Date();
      startTime.setMinutes(startTime.getMinutes() + 1);
      startTime.setSeconds(0);
      startTime.setMilliseconds(0);

      for (let i = 0; i < numberOfNotifications; i++) {
        const scheduledTime = new Date(startTime);
        scheduledTime.setSeconds(scheduledTime.getSeconds() + (i * intervalSeconds));
        
        const identifier = await Notifications.scheduleNotificationAsync({
          content: {
            title: `تنبيه متتابع (${i + 1}/${numberOfNotifications}) 🕒`,
            body: `تنبيه رقم ${i + 1}`,
            sound: true,
            priority: Notifications.AndroidNotificationPriority.HIGH,
          },
          trigger: {
            date: scheduledTime,
            channelId: 'scheduled-sequence'
          },
        });
        console.log(`Notification ${i + 1} scheduled with ID: ${identifier} for ${scheduledTime.toLocaleTimeString()}`);
        notificationIdentifiers.push(identifier);
      }
      setScheduledNotificationIds(notificationIdentifiers);
      Alert.alert(
        'تمت الجدولة',
        `تم جدولة ${numberOfNotifications} تنبيهات متتالية تبدأ في ${startTime.toLocaleTimeString()} بفاصل ${intervalSeconds} ثوانٍ بين كل تنبيه.`
      );
    } catch (error) {
      console.error('Error scheduling notification sequence:', error);
      Alert.alert('خطأ', 'حدث خطأ أثناء جدولة سلسلة التنبيهات.');
    }
  }

  // --- وظيفة إلغاء جميع التنبيهات المجدولة في السلسلة ---
  async function cancelAllScheduledNotifications() {
    if (scheduledNotificationIds.length > 0) {
      console.log('Cancelling all scheduled notifications:', scheduledNotificationIds);
      await Promise.all(scheduledNotificationIds.map(id => Notifications.cancelScheduledNotificationAsync(id)));
      setScheduledNotificationIds([]);
    } else {
      console.log('No scheduled notifications to cancel.');
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>محاكاة تنبيه متتابع (3 ثوانٍ)</Text>
      <Text style={styles.info}>سيتم إرسال التنبيهات بفاصل 3 ثوانٍ بين كل تنبيه. انقر على أي إشعار لإيقاف السلسلة.</Text>
      <View style={styles.buttonContainer}>
        <Button
          title={`جدولة ${10} تنبيهات (فاصل 3 ثوانٍ)`}
          onPress={scheduleSequenceAtSpecificTime}
          disabled={scheduledNotificationIds.length > 0}
        />
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="إلغاء جميع التنبيهات المجدولة"
          onPress={cancelAllScheduledNotifications}
          disabled={scheduledNotificationIds.length === 0}
          color="red"
        />
      </View>
    </ScrollView>
  );
}

// --- وظيفة طلب أذونات الإشعارات وإنشاء قناة مخصصة ---
async function registerForPushNotificationsAsync() {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('scheduled-sequence', {
      name: 'Scheduled Sequence Alarms',
      importance: Notifications.AndroidImportance.HIGH,
      sound: 'default',
      enableVibrate: true,
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync({
        ios: {
          allowAlert: true,
          allowBadge: true,
          allowSound: true,
        },
      });
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      Alert.alert('فشل الحصول على إذن الإشعارات!');
      return;
    }
  } else {
    Alert.alert('يجب استخدام جهاز حقيقي لاختبار الإشعارات');
  }
}

// --- الأنماط ---
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  info: {
    textAlign: 'center',
    marginBottom: 10,
  },
  buttonContainer: {
    marginVertical: 10,
    width: '90%',
  },
}); 