import React, { useState, useCallback, useRef, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions, 
  SafeAreaView, 
  TouchableOpacity,
  ActivityIndicator,
  Animated,
  StatusBar
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { BarChart, LineChart, PieChart } from 'react-native-gifted-charts';
import { getHabits } from '../utils/habitStorage';
import { Habit, QuantitativeHabit, CommitmentHabit } from '../types';
import { COLORS, SPACING } from '../theme';

const { width } = Dimensions.get('window');

type PeriodType = 'week' | 'month' | 'all';
type ViewMode = 'all' | 'quantitative' | 'commitment';

const StatsScreen = () => {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<PeriodType>('week');
  const [viewMode, setViewMode] = useState<ViewMode>('all');
  const [quantitativeData, setQuantitativeData] = useState<any[]>([]);
  const [commitmentData, setCommitmentData] = useState<any[]>([]);
  const [pieData, setPieData] = useState<any[]>([]);
  const [selectedHabitId, setSelectedHabitId] = useState<string | null>(null);
  
  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;
  const chartFadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Run entrance animations when view changes
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      })
    ]).start();
  }, [viewMode]);

  useEffect(() => {
    // Run chart animation when data changes
    Animated.timing(chartFadeAnim, {
      toValue: 1,
      duration: 800,
      delay: 300,
      useNativeDriver: true,
    }).start();
    
    return () => {
      chartFadeAnim.setValue(0);
    };
  }, [quantitativeData, commitmentData]);

  const processData = useCallback((loadedHabits: Habit[]) => {
    // Filter habits based on viewMode
    const filteredHabits = viewMode === 'all' 
      ? loadedHabits 
      : loadedHabits.filter(h => h.type === viewMode);
    
    // Process pie chart data for habit types
    const typeCountMap = loadedHabits.reduce((acc, habit) => {
      acc[habit.type] = (acc[habit.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const pieChartData = [
      {
        value: typeCountMap['quantitative'] || 0,
        color: COLORS.primary,
        text: 'كمية',
        focused: viewMode === 'quantitative',
        gradientCenterColor: COLORS.primaryLight,
      },
      {
        value: typeCountMap['commitment'] || 0,
        color: COLORS.secondary,
        text: 'التزام',
        focused: viewMode === 'commitment',
        gradientCenterColor: COLORS.secondaryLight,
      }
    ];
    setPieData(pieChartData);

    // Get time period constraint
    const now = new Date();
    const cutoffDate = new Date();
    if (period === 'week') {
      cutoffDate.setDate(now.getDate() - 7);
    } else if (period === 'month') {
      cutoffDate.setMonth(now.getMonth() - 1);
    } else {
      // 'all' - use a very old date to include everything
      cutoffDate.setFullYear(2000);
    }

    // Process quantitative data
    let processedQuantData: any[] = [];
    const quantHabits = filteredHabits.filter(h => h.type === 'quantitative') as QuantitativeHabit[];
    
    // Filter by selectedHabitId or take the first habit
    const habitToProcess = selectedHabitId 
      ? quantHabits.find(h => h.id === selectedHabitId) 
      : quantHabits[0];
    
    if (habitToProcess && habitToProcess.logs.length > 0) {
      // Filter logs by time period
      const filteredLogs = habitToProcess.logs.filter(
        log => new Date(log.date) > cutoffDate
      );
      
      // Group logs by date and sum values
      const dailyTotals: { [key: string]: number } = {};
      filteredLogs.forEach(log => {
        const dateStr = new Date(log.date).toLocaleDateString();
        dailyTotals[dateStr] = (dailyTotals[dateStr] || 0) + log.value;
      });
      
      // Get max value for better bar heights
      const maxValue = Math.max(...Object.values(dailyTotals), habitToProcess.goal);
      
      // Convert to chart format
      processedQuantData = Object.entries(dailyTotals).map(([date, value], index) => {
        // Calculate if goal is met
        const goalMet = value >= habitToProcess.goal;
        
        return {
          value: value,
          label: date.substring(0, 5),
          frontColor: goalMet ? COLORS.success : COLORS.primary,
          topLabelComponent: () => (
            <Text style={[
              styles.barLabel, 
              { color: goalMet ? COLORS.success : COLORS.primary }
            ]}>
              {value}
            </Text>
          ),
          // Add gradients
          gradientColor: goalMet ? 'rgba(76, 175, 80, 0.5)' : 'rgba(33, 150, 243, 0.5)',
        };
      });
    }
    setQuantitativeData(processedQuantData);

    // Process commitment data
    let processedCommitData: any[] = [];
    const commitHabits = filteredHabits.filter(h => h.type === 'commitment') as CommitmentHabit[];
    
    // Filter by selectedHabitId or take the first habit
    const commitHabitToProcess = selectedHabitId
      ? commitHabits.find(h => h.id === selectedHabitId)
      : commitHabits[0];
      
    if (commitHabitToProcess && commitHabitToProcess.logs.length > 0) {
      // Filter logs by time period
      const filteredLogs = commitHabitToProcess.logs.filter(
        log => new Date(log.date) > cutoffDate
      );
      
      // Convert to chart format with proper dates
      processedCommitData = filteredLogs.map((log, index) => ({
        value: log.committed ? 1 : 0,
        label: new Date(log.date).toLocaleDateString().substring(0, 5),
        dataPointLabelComponent: () => (
          <Text style={{
            color: log.committed ? COLORS.success : COLORS.error, 
            fontSize: 14, 
            fontWeight: 'bold',
            backgroundColor: log.committed ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)',
            width: 20,
            height: 20,
            textAlign: 'center',
            borderRadius: 10,
            overflow: 'hidden',
            lineHeight: 20
          }}>
            {log.committed ? '✓' : '✗'}
          </Text>
        ),
        dataPointLabelShiftY: -15,
        dataPointLabelShiftX: 0,
        // Styling
        customDataPoint: log.committed,
        dataPointColor: log.committed ? COLORS.success : COLORS.error,
      }));
    }
    setCommitmentData(processedCommitData);

    setLoading(false);
  }, [period, viewMode, selectedHabitId]);

  const loadData = useCallback(async () => {
    setLoading(true);
    const storedHabits = await getHabits();
    setHabits(storedHabits);
    processData(storedHabits);
  }, [processData]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const handlePeriodChange = (newPeriod: PeriodType) => {
    setPeriod(newPeriod);
    chartFadeAnim.setValue(0);
  };

  const handleViewModeChange = (newMode: ViewMode) => {
    fadeAnim.setValue(0);
    slideAnim.setValue(20);
    chartFadeAnim.setValue(0);
    setViewMode(newMode);
    // Reset selected habit when changing view mode
    setSelectedHabitId(null);
  };

  const handleHabitSelect = (habitId: string) => {
    chartFadeAnim.setValue(0);
    setSelectedHabitId(habitId === selectedHabitId ? null : habitId);
  };

  const renderHabitSelector = () => {
    const relevantHabits = habits.filter(h => 
      viewMode === 'all' || h.type === viewMode
    );
    
    if (relevantHabits.length === 0) return null;
    
    return (
      <Animated.View 
        style={[
          styles.habitSelector,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }]
          }
        ]}
      >
        <Text style={styles.selectorTitle}>اختر عادة لعرض إحصائياتها:</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {relevantHabits.map(habit => (
            <TouchableOpacity
              key={habit.id}
              style={[
                styles.habitChip,
                selectedHabitId === habit.id && styles.habitChipSelected,
                { 
                  backgroundColor: habit.type === 'quantitative' 
                    ? 'rgba(74, 111, 165, 0.1)' 
                    : 'rgba(255, 126, 103, 0.1)' 
                }
              ]}
              onPress={() => handleHabitSelect(habit.id)}
              activeOpacity={0.7}
            >
              <Text 
                style={[
                  styles.habitChipText,
                  { 
                    color: habit.type === 'quantitative' ? COLORS.primary : COLORS.secondary 
                  },
                  selectedHabitId === habit.id && styles.habitChipTextSelected
                ]}
              >
                {habit.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </Animated.View>
    );
  };

  const getHabitSummary = () => {
    if (habits.length === 0) return null;
    
    const totalHabits = habits.length;
    const activeHabits = habits.filter(h => {
      const lastLog = h.logs.length > 0 ? h.logs[h.logs.length - 1] : null;
      if (!lastLog) return false;
      
      const lastLogDate = new Date(lastLog.date);
      const now = new Date();
      const daysDiff = Math.floor((now.getTime() - lastLogDate.getTime()) / (1000 * 60 * 60 * 24));
      
      return daysDiff < 3; // Active if logged in the last 3 days
    }).length;
    
    const completedLogsCount = habits.reduce((sum, habit) => sum + habit.logs.length, 0);
    
    const longestStreak = habits
      .filter(h => h.type === 'commitment')
      .reduce((max, h) => Math.max(max, (h as CommitmentHabit).longestStreak), 0);
    
    return (
      <Animated.View style={[
        styles.summaryContainer,
        {
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }
      ]}>
        <View style={[styles.summaryCard, styles.cardGlow]}>
          <Text style={styles.summaryValue}>{totalHabits}</Text>
          <Text style={styles.summaryLabel}>العادات الكلية</Text>
          <View style={styles.cardIconContainer}>
            <Text style={styles.cardIcon}>📊</Text>
          </View>
        </View>
        
        <View style={[styles.summaryCard, styles.cardGlow]}>
          <Text style={styles.summaryValue}>{activeHabits}</Text>
          <Text style={styles.summaryLabel}>العادات النشطة</Text>
          <View style={[styles.cardIconContainer, { backgroundColor: 'rgba(76, 175, 80, 0.1)' }]}>
            <Text style={styles.cardIcon}>✅</Text>
          </View>
        </View>
        
        <View style={[styles.summaryCard, styles.cardGlow]}>
          <Text style={styles.summaryValue}>{completedLogsCount}</Text>
          <Text style={styles.summaryLabel}>إجمالي الإنجازات</Text>
          <View style={[styles.cardIconContainer, { backgroundColor: 'rgba(33, 150, 243, 0.1)' }]}>
            <Text style={styles.cardIcon}>🏆</Text>
          </View>
        </View>
        
        <View style={[styles.summaryCard, styles.cardGlow]}>
          <Text style={styles.summaryValue}>{longestStreak}</Text>
          <Text style={styles.summaryLabel}>أطول استمرارية</Text>
          <View style={[styles.cardIconContainer, { backgroundColor: 'rgba(255, 152, 0, 0.1)' }]}>
            <Text style={styles.cardIcon}>🔥</Text>
          </View>
        </View>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar backgroundColor={COLORS.background} barStyle="dark-content" />
      
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>الإحصائيات والتحليلات</Text>

        {/* Filter Controls */}
        <View style={styles.filterContainer}>
          <View style={[styles.periodSelector, styles.cardGlow]}>
            <TouchableOpacity
              style={[styles.periodOption, period === 'week' && styles.periodOptionSelected]}
              onPress={() => handlePeriodChange('week')}
            >
              <Text style={[styles.periodText, period === 'week' && styles.periodTextSelected]}>أسبوع</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.periodOption, period === 'month' && styles.periodOptionSelected]}
              onPress={() => handlePeriodChange('month')}
            >
              <Text style={[styles.periodText, period === 'month' && styles.periodTextSelected]}>شهر</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.periodOption, period === 'all' && styles.periodOptionSelected]}
              onPress={() => handlePeriodChange('all')}
            >
              <Text style={[styles.periodText, period === 'all' && styles.periodTextSelected]}>الكل</Text>
            </TouchableOpacity>
          </View>
          
          <View style={[styles.viewModeSelector, styles.cardGlow]}>
            <TouchableOpacity
              style={[styles.viewModeOption, viewMode === 'all' && styles.viewModeOptionSelected]}
              onPress={() => handleViewModeChange('all')}
            >
              <Text style={[styles.viewModeText, viewMode === 'all' && styles.viewModeTextSelected]}>الكل</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.viewModeOption, viewMode === 'quantitative' && styles.viewModeOptionSelected]}
              onPress={() => handleViewModeChange('quantitative')}
            >
              <Text style={[styles.viewModeText, viewMode === 'quantitative' && styles.viewModeTextSelected]}>كمي</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.viewModeOption, viewMode === 'commitment' && styles.viewModeOptionSelected]}
              onPress={() => handleViewModeChange('commitment')}
            >
              <Text style={[styles.viewModeText, viewMode === 'commitment' && styles.viewModeTextSelected]}>التزام</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Habit Selector */}
        {renderHabitSelector()}

        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={COLORS.primary} />
            <Text style={styles.loadingText}>جاري تحميل الإحصائيات...</Text>
          </View>
        ) : (
          <>
            {/* Summary Statistics */}
            {getHabitSummary()}

            {/* Distribution Pie Chart */}
            <Animated.View style={[
              styles.chartCard, 
              styles.cardGlow,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }]
              }
            ]}>
              <View style={styles.chartHeader}>
                <Text style={styles.chartTitle}>توزيع أنواع العادات</Text>
                <View style={styles.chartIconContainer}>
                  <Text style={styles.chartIcon}>📊</Text>
                </View>
              </View>
              
              <Animated.View 
                style={[
                  styles.pieChartContainer,
                  { opacity: chartFadeAnim }
                ]}
              >
                {pieData[0].value + pieData[1].value > 0 ? (
                  <PieChart
                    data={pieData}
                    donut
                    showGradient
                    sectionAutoFocus
                    radius={90}
                    innerRadius={60}
                    innerCircleColor={COLORS.background}
                    centerLabelComponent={() => (
                      <Text style={styles.pieChartCenterLabel}>{habits.length}</Text>
                    )}
                  />
                ) : (
                  <Text style={styles.noDataText}>لا توجد بيانات كافية</Text>
                )}
              </Animated.View>
              
              <View style={styles.legendContainer}>
                <View style={styles.legendItem}>
                  <View style={[styles.legendColor, {backgroundColor: COLORS.primary}]} />
                  <Text style={styles.legendText}>كمية</Text>
                </View>
                <View style={styles.legendItem}>
                  <View style={[styles.legendColor, {backgroundColor: COLORS.secondary}]} />
                  <Text style={styles.legendText}>التزام</Text>
                </View>
              </View>
            </Animated.View>

            {/* Quantitative Chart */}
            {(viewMode === 'all' || viewMode === 'quantitative') && (
              <Animated.View style={[
                styles.chartCard, 
                styles.cardGlow,
                {
                  opacity: fadeAnim,
                  transform: [{ translateY: slideAnim }]
                }
              ]}>
                <View style={styles.chartHeader}>
                  <Text style={styles.chartTitle}>
                    إنجازات العادات الكمية
                    {selectedHabitId && habits.find(h => h.id === selectedHabitId) && 
                      ` - ${habits.find(h => h.id === selectedHabitId)?.name}`
                    }
                  </Text>
                  <View style={styles.chartIconContainer}>
                    <Text style={styles.chartIcon}>📈</Text>
                  </View>
                </View>
                
                {quantitativeData.length > 0 ? (
                  <Animated.View 
                    style={[
                      styles.barChartContainer,
                      { opacity: chartFadeAnim }
                    ]}
                  >
                    <BarChart
                      data={quantitativeData}
                      barWidth={30}
                      spacing={20}
                      roundedTop
                      roundedBottom
                      hideRules
                      xAxisThickness={1}
                      yAxisThickness={1}
                      yAxisTextStyle={styles.axisText}
                      xAxisLabelTextStyle={styles.axisText}
                      noOfSections={5}
                      barBorderRadius={8}
                      width={width - 80}
                      disablePress
                      frontColor={COLORS.primary}
                      yAxisColor={COLORS.border}
                      xAxisColor={COLORS.border}
                      dashWidth={0}
                      backgroundColor={COLORS.white}
                      showGradient
                      showReferenceLine1
                      referenceLine1Position={0}
                      referenceLine1Config={{
                        color: COLORS.border,
                        dashWidth: 2,
                        dashGap: 3,
                      }}
                    />
                  </Animated.View>
                ) : (
                  <Text style={styles.noDataText}>
                    {habits.some(h => h.type === 'quantitative') 
                      ? 'لا توجد بيانات كافية للفترة المحددة'
                      : 'لم تقم بإضافة عادات كمية بعد'}
                  </Text>
                )}
              </Animated.View>
            )}

            {/* Commitment Chart */}
            {(viewMode === 'all' || viewMode === 'commitment') && (
              <Animated.View style={[
                styles.chartCard, 
                styles.cardGlow,
                {
                  opacity: fadeAnim,
                  transform: [{ translateY: slideAnim }]
                }
              ]}>
                <View style={styles.chartHeader}>
                  <Text style={styles.chartTitle}>
                    سجل الالتزام
                    {selectedHabitId && habits.find(h => h.id === selectedHabitId) && 
                      ` - ${habits.find(h => h.id === selectedHabitId)?.name}`
                    }
                  </Text>
                  <View style={styles.chartIconContainer}>
                    <Text style={styles.chartIcon}>📅</Text>
                  </View>
                </View>
                
                {commitmentData.length > 0 ? (
                  <Animated.View 
                    style={[
                      styles.lineChartContainer,
                      { opacity: chartFadeAnim }
                    ]}
                  >
                    <LineChart
                      areaChart
                      curved
                      data={commitmentData}
                      height={180}
                      spacing={30}
                      thickness={4}
                      color={COLORS.success}
                      dataPointsHeight={12}
                      dataPointsWidth={12}
                      dataPointsColor={COLORS.success}
                      startFillColor="rgba(76, 175, 80, 0.3)"
                      endFillColor="rgba(76, 175, 80, 0.05)"
                      startOpacity={0.9}
                      endOpacity={0.2}
                      noOfSections={1}
                      maxValue={1.1}
                      yAxisColor={COLORS.border}
                      xAxisColor={COLORS.border}
                      hideRules
                      width={width - 80}
                      yAxisLabelTexts={['❌', '✓']}
                      showYAxisIndices
                      rulesColor={COLORS.border}
                      yAxisLabelWidth={30}
                      disableScroll
                      hideDataPoints={false}
                      pointerConfig={{
                        pointerStripHeight: 160,
                        pointerStripColor: COLORS.primary,
                        pointerStripWidth: 2,
                        pointerColor: COLORS.primary,
                        radius: 6,
                        pointerLabelWidth: 100,
                        pointerLabelHeight: 90,
                        activatePointersOnLongPress: true,
                        autoAdjustPointerLabelPosition: true,
                        pointerLabelComponent: (items: any) => {
                          return (
                            <View style={styles.pointerLabel}>
                              <Text style={styles.pointerLabelText}>{items[0].label}</Text>
                              <Text style={styles.pointerValueText}>
                                {items[0].value === 1 ? 'ملتزم ✓' : 'غير ملتزم ✗'}
                              </Text>
                            </View>
                          );
                        },
                      }}
                    />
                  </Animated.View>
                ) : (
                  <Text style={styles.noDataText}>
                    {habits.some(h => h.type === 'commitment') 
                      ? 'لا توجد بيانات كافية للفترة المحددة'
                      : 'لم تقم بإضافة عادات التزام بعد'}
                  </Text>
                )}
              </Animated.View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
    paddingHorizontal: SPACING.md,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginVertical: SPACING.lg,
    textAlign: 'center',
    color: COLORS.primary,
  },
  filterContainer: {
    marginBottom: SPACING.lg,
  },
  periodSelector: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: SPACING.md,
    backgroundColor: COLORS.white,
    borderRadius: 20,
    padding: SPACING.sm,
  },
  periodOption: {
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    marginHorizontal: SPACING.xs,
    borderRadius: 15,
    backgroundColor: 'transparent',
  },
  periodOptionSelected: {
    backgroundColor: COLORS.primary,
  },
  periodText: {
    color: COLORS.textDark,
    fontWeight: '500',
  },
  periodTextSelected: {
    color: COLORS.white,
  },
  viewModeSelector: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: SPACING.sm,
    backgroundColor: COLORS.white,
    borderRadius: 20,
    padding: SPACING.sm,
  },
  viewModeOption: {
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    marginHorizontal: SPACING.xs,
    borderRadius: 15,
    backgroundColor: 'transparent',
  },
  viewModeOptionSelected: {
    backgroundColor: COLORS.primaryLight,
  },
  viewModeText: {
    color: COLORS.textDark,
    fontWeight: '500',
  },
  viewModeTextSelected: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  habitSelector: {
    marginBottom: SPACING.lg,
    backgroundColor: COLORS.white,
    borderRadius: 20,
    padding: SPACING.md,
  },
  selectorTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textDark,
    marginBottom: SPACING.sm,
    textAlign: 'center',
  },
  habitChip: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginHorizontal: 6,
    borderRadius: 20,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  habitChipSelected: {
    borderColor: COLORS.primary,
  },
  habitChipText: {
    fontWeight: '600',
  },
  habitChipTextSelected: {
    fontWeight: 'bold',
  },
  chartCard: {
    backgroundColor: COLORS.white,
    borderRadius: 24,
    padding: SPACING.lg,
    marginBottom: SPACING.lg,
  },
  cardGlow: {
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 15,
    elevation: 6,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  chartIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chartIcon: {
    fontSize: 20,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textDark,
  },
  pieChartContainer: {
    alignItems: 'center',
    marginVertical: SPACING.md,
    height: 200,
    justifyContent: 'center',
  },
  pieChartCenterLabel: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  barChartContainer: {
    marginVertical: SPACING.md,
    alignItems: 'center',
  },
  lineChartContainer: {
    marginVertical: SPACING.md,
    alignItems: 'center',
  },
  barLabel: {
    color: COLORS.textDark,
    fontSize: 12,
    fontWeight: 'bold',
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: SPACING.md,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: SPACING.md,
  },
  legendColor: {
    width: 14,
    height: 14,
    borderRadius: 7,
    marginRight: SPACING.xs,
  },
  legendText: {
    color: COLORS.textDark,
    fontSize: 14,
    fontWeight: '500',
  },
  noDataText: {
    textAlign: 'center',
    color: COLORS.textMedium,
    fontStyle: 'italic',
    marginVertical: SPACING.xl,
  },
  summaryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: SPACING.lg,
  },
  summaryCard: {
    width: '48%',
    backgroundColor: COLORS.white,
    borderRadius: 20,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  cardIconContainer: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardIcon: {
    fontSize: 16,
  },
  summaryValue: {
    fontSize: 36,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  summaryLabel: {
    fontSize: 14,
    color: COLORS.textMedium,
    marginTop: SPACING.xs,
    textAlign: 'center',
  },
  loadingContainer: {
    padding: SPACING.xl,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: SPACING.md,
    color: COLORS.textMedium,
    fontSize: 16,
  },
  axisText: {
    color: COLORS.textMedium,
    fontSize: 12,
  },
  pointerLabel: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 10,
    width: 100,
    alignItems: 'center',
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  pointerLabelText: {
    fontSize: 12,
    color: COLORS.textMedium,
    marginBottom: 4,
  },
  pointerValueText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.textDark,
  }
});

export default StatsScreen;

