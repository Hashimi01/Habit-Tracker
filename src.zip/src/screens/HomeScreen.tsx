import React, { useState, useCallback } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  SafeAreaView, 
  Alert,
  Image,
  StatusBar,
  I18nManager
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { getHabits, deleteHabit } from '../utils/habitStorage';
import { Habit, RootStackParamList, CommitmentHabit, CommitmentLog } from '../types';
import { COLORS, SPACING } from '../theme';

// Force RTL layout direction
I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

// Define navigation prop type specifically for HomeScreen
type HomeScreenNavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  'Home'
>;

const HomeScreen = () => {
  const navigation = useNavigation<HomeScreenNavigationProp>();
  const [habits, setHabits] = useState<Habit[]>([]);

  const loadHabits = useCallback(async () => {
    const storedHabits = await getHabits();
    
    // Calculate commitment percentages for commitment habits if not already set
    const updatedHabits = storedHabits.map(habit => {
      if (habit.type === 'commitment') {
        const commitmentHabit = habit as CommitmentHabit;
        if (commitmentHabit.logs.length > 0 && !('commitmentPercentage' in commitmentHabit)) {
          const totalLogs = commitmentHabit.logs.length;
          const committedLogs = commitmentHabit.logs.filter((log: CommitmentLog) => log.committed).length;
          const commitmentPercentage = (committedLogs / totalLogs) * 100;
          
          // Update the habit with the calculated percentage
          return {
            ...commitmentHabit,
            commitmentPercentage: commitmentPercentage
          };
        }
      }
      return habit;
    });
    
    // Save the updated habits if any percentages were calculated
    const needsUpdate = updatedHabits.some((habit, index) => 
      habit.type === 'commitment' && 
      'commitmentPercentage' in habit && habit.commitmentPercentage !== undefined && 
      storedHabits[index].type === 'commitment' && 
      !('commitmentPercentage' in storedHabits[index] as any)
    );
    
    if (needsUpdate) {
      // Import the updateHabits function
      const { updateHabits } = require('../utils/habitStorage');
      await updateHabits(updatedHabits);
    }
    
    setHabits(updatedHabits);
  }, []);

  // useFocusEffect runs when the screen comes into focus
  useFocusEffect(
    useCallback(() => {
      loadHabits();
    }, [loadHabits])
  );

  const handleDeleteHabit = async (habitId: string, habitName: string) => {
    Alert.alert(
      'تأكيد الحذف',
      `هل أنت متأكد من حذف "${habitName}"؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        { 
          text: 'حذف', 
          onPress: async () => {
            try {
              const updatedHabits = await deleteHabit(habitId);
              setHabits(updatedHabits);
            } catch (error) {
              console.error('Failed to delete habit:', error);
              Alert.alert('خطأ', 'حدث خطأ أثناء حذف العادة.');
            }
          },
          style: 'destructive'
        },
      ]
    );
  };

  const getHabitIcon = (type: string) => {
    if (type === 'quantitative') {
      return '📊'; // Chart emoji for quantitative habits
    } else {
      return '✅'; // Checkbox emoji for commitment habits
    }
  };

  const renderHabit = ({ item }: { item: Habit }) => (
    <TouchableOpacity 
      style={styles.habitCard}
      onPress={() => navigation.navigate('HabitDetail', { habitId: item.id })}
      activeOpacity={0.7}
    >
      <View style={styles.habitIconContainer}>
        <Text style={styles.habitIcon}>{getHabitIcon(item.type)}</Text>
      </View>
      
      <View style={styles.habitInfo}>
        <Text style={styles.habitName} numberOfLines={1} ellipsizeMode="tail">{item.name}</Text>
        <Text style={styles.habitType} numberOfLines={1} ellipsizeMode="tail">
          {item.type === 'quantitative' ? 'كمي' : 'التزام'}
          {item.type === 'quantitative' && ` • ${item.goal} ${item.unit}`}
          {item.type === 'commitment' && 'commitmentPercentage' in item && item.commitmentPercentage !== undefined && 
           ` • ${item.commitmentPercentage.toFixed(1)}%`}
        </Text>
      </View>
      
      <TouchableOpacity 
        style={styles.deleteButton}
        onPress={() => handleDeleteHabit(item.id, item.name)}
      >
        <Text style={styles.deleteButtonText}>حذف</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar backgroundColor={COLORS.background} barStyle="dark-content" />
      
      <View style={styles.header}>
        <Text style={styles.title}>عاداتي</Text>
      </View>
      
      {habits.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>🌱</Text>
          <Text style={styles.emptyTitle}>لم تقم بإضافة أي عادات بعد</Text>
          <Text style={styles.emptySubtitle}>أضف عادتك الأولى للبدء في تتبع تقدمك</Text>
        </View>
      ) : (
        <FlatList
          data={habits}
          renderItem={renderHabit}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
      
      <TouchableOpacity 
        style={styles.addButton}
        onPress={() => navigation.navigate('AddHabit')}
      >
        <Text style={styles.addButtonText}>+ إضافة عادة جديدة</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    padding: SPACING.lg,
    paddingBottom: SPACING.md,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.primary,
    textAlign: 'center',
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xl,
  },
  emptyIcon: {
    fontSize: 70,
    marginBottom: SPACING.lg,
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.textDark,
    marginBottom: SPACING.sm,
    textAlign: 'center',
    includeFontPadding: false,
    lineHeight: 32,
  },
  emptySubtitle: {
    fontSize: 16,
    color: COLORS.textMedium,
    textAlign: 'center',
    includeFontPadding: false,
    lineHeight: 24,
  },
  list: {
    padding: SPACING.md,
  },
  habitCard: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  habitIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: COLORS.primaryLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: SPACING.md,
    marginLeft: SPACING.xs,
  },
  habitIcon: {
    fontSize: 24,
  },
  habitInfo: {
    flex: 1,
    marginHorizontal: SPACING.sm,
    paddingRight: SPACING.md,
  },
  habitName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textDark,
    marginBottom: 4,
    includeFontPadding: false,
    textAlign: 'right',
  },
  habitType: {
    fontSize: 14,
    color: COLORS.textMedium,
    includeFontPadding: false,
    textAlign: 'right',
  },
  deleteButton: {
    backgroundColor: COLORS.error,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginLeft: SPACING.sm,
  },
  deleteButtonText: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 14,
    includeFontPadding: false,
  },
  addButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    padding: SPACING.md,
    margin: SPACING.lg,
    alignItems: 'center',
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  addButtonText: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 18,
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
});

export default HomeScreen;

